"""Official Ark Seedance 2.0 clips. Durable task IDs; never retry paid POSTs."""
import base64
import hashlib
import json
import os
import re
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import key_store

API = 'https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks'
MODEL = 'doubao-seedance-2-0-260128'
KEY, KEY_NOTICE = key_store.load('ark')
KEY = KEY or os.environ.get('ARK_API_KEY', '')
ACTIVE = set()
MAX_VIDEO = 300 * 1024 * 1024


def require(ok, message):
    if not ok:
        raise ValueError(message)


def folder(app, pid):
    app.path(pid)  # validate project identifier
    return app.DATA / 'videos' / pid


def read_json(path, default=None):
    return json.loads(path.read_text('utf-8')) if path.exists() else default


def job_path(app, pid, jid):
    require(isinstance(jid, str) and re.fullmatch('[a-f0-9]{32}', jid), '视频任务编号无效')
    return folder(app, pid) / 'tasks' / (jid + '.json')


def save_job(app, record):
    app.updater.save_json(job_path(app, record['pid'], record['id']), record)


def public_job(app, record):
    result = {k: v for k, v in record.items() if k not in ('video_url', 'payload')}
    result['local_video'] = (folder(app, record['pid']) / (record['id'] + '.mp4')).exists()
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('接口发生重定向，已停止请求。')


def request(key, task_id=None, payload=None):
    if task_id:
        require(re.fullmatch(r'cgt-[A-Za-z0-9-]{1,120}', task_id), '平台任务编号无效')
    url = API + ('/' + task_id if task_id else '')
    req = urllib.request.Request(url, data=json.dumps(payload).encode() if payload is not None else None,
                                 headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
    # No POST retry and no credential-bearing redirects.
    with urllib.request.build_opener(NoRedirect()).open(req, timeout=60) as response:
        raw = response.read(2 * 1024 * 1024 + 1)
    require(len(raw) <= 2 * 1024 * 1024, '平台响应过大')
    value = json.loads(raw)
    require(isinstance(value, dict), '平台响应格式异常')
    return value


def error_message(error):
    if isinstance(error, urllib.error.HTTPError):
        return {401: '方舟密钥无效，请重新保存。', 403: '方舟账号无权使用该模型，请检查开通状态与权限。',
                400: '平台拒绝请求，请检查提示词、参考图或人像授权。', 402: '请检查方舟余额。',
                429: '平台限流或额度不足，请稍后查询。'}.get(error.code, '平台服务暂不可用，请稍后查询。') + ' HTTP ' + str(error.code)
    # Do not echo urllib messages, headers, signed URLs or API credentials.
    return '网络或平台响应异常，请核对方舟任务记录。'


def image_size(raw):
    if raw.startswith(b'\x89PNG\r\n\x1a\n') and len(raw) >= 24 and raw[12:16] == b'IHDR':
        return 'png', *struct.unpack('>II', raw[16:24])
    if raw.startswith(b'\xff\xd8'):
        i = 2
        while i + 4 < len(raw):
            if raw[i] != 255:
                break
            while i < len(raw) and raw[i] == 255:
                i += 1
            marker = raw[i]; i += 1
            if marker in (0xd8, 0xd9):
                continue
            size = int.from_bytes(raw[i:i+2], 'big')
            if size < 2 or i + size > len(raw):
                break
            if marker in (0xc0, 0xc1, 0xc2) and size >= 7:
                return 'jpeg', int.from_bytes(raw[i+5:i+7], 'big'), int.from_bytes(raw[i+3:i+5], 'big')
            i += size
    raise ValueError('请使用有效的 PNG 或 JPEG 图片。')


def asset_add(app, pid, data):
    name = str(data.get('name', '')).strip()
    require(0 < len(name) <= 80, '请填写参考图名称（最多80字）')
    asset_uri = str(data.get('asset_uri', '')).strip()
    assets_path = folder(app, pid) / 'assets.json'
    assets = read_json(assets_path, [])
    require(len(assets) < 100, '本项目参考素材最多100项')
    if asset_uri:
        require(re.fullmatch(r'asset://[A-Za-z0-9_-]{1,160}', asset_uri), '请输入方舟素材库的 asset:// 素材编号')
        item = {'id': hashlib.sha256(asset_uri.encode()).hexdigest()[:24], 'name': name, 'uri': asset_uri}
    else:
        value = data.get('data', '')
        require(isinstance(value, str) and len(value) <= 6 * 1024 * 1024, '单张参考图请压缩至4MB以内')
        match = re.fullmatch(r'data:image/(png|jpeg);base64,([A-Za-z0-9+/=\r\n]+)', value)
        require(match, '仅支持PNG或JPEG参考图')
        raw = base64.b64decode(match[2], validate=True)
        require(len(raw) <= 4 * 1024 * 1024, '单张参考图请压缩至4MB以内')
        fmt, width, height = image_size(raw)
        require(fmt == match[1] and 300 <= width <= 6000 and 300 <= height <= 6000 and .4 <= width / height <= 2.5,
                '图片宽高需在300—6000像素，宽高比在0.4—2.5之间')
        ident = hashlib.sha256(raw).hexdigest()[:24]
        dest = folder(app, pid) / 'assets' / (ident + '.' + fmt)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
        item = {'id': ident, 'name': name, 'format': fmt, 'width': width, 'height': height}
    assets = [v for v in assets if v['id'] != item['id']] + [item]
    app.updater.save_json(assets_path, assets)
    return {'assets': assets}


def make_payload(app, pid, data):
    prompt = str(data.get('prompt', '')).strip()
    require(0 < len(prompt) <= 6000, '请填写视频提示词，最多6000字')
    resolution = data.get('resolution', '720p')
    duration = data.get('duration', 10)
    audio = data.get('audio', True)
    require(resolution in ('480p', '720p'), '分辨率仅支持480p或720p')
    require(type(duration) is int and 4 <= duration <= 15, '时长支持4—15秒')
    require(type(audio) is bool, '声音设置无效')
    ids = data.get('assets', [])
    require(isinstance(ids, list) and len(ids) <= 9 and all(isinstance(i, str) for i in ids) and len(set(ids)) == len(ids), '每段最多选择9张不同参考图')
    available = {v['id']: v for v in read_json(folder(app, pid) / 'assets.json', [])}
    content, names = [], []
    for i, ident in enumerate(ids, 1):
        require(ident in available, '参考图不存在，请重新选择')
        asset = available[ident]
        uri = asset.get('uri')
        if not uri:
            raw = (folder(app, pid) / 'assets' / (ident + '.' + asset['format'])).read_bytes()
            uri = 'data:image/' + asset['format'] + ';base64,' + base64.b64encode(raw).decode()
        content.append({'type': 'image_url', 'image_url': {'url': uri}, 'role': 'reference_image'})
        names.append('图片' + str(i) + '对应：' + asset['name'])
    if names:
        prompt = '\n'.join(names) + '\n保持参考角色的外貌、发型、服装一致。\n' + prompt
    content.insert(0, {'type': 'text', 'text': prompt})
    return {'model': MODEL, 'content': content, 'resolution': resolution, 'ratio': '16:9',
            'duration': duration, 'generate_audio': audio}


def valid_media_url(url):
    parts = urllib.parse.urlsplit(url)
    require(parts.scheme == 'https' and parts.hostname and parts.hostname.endswith('.volces.com')
            and parts.port in (None, 443) and not parts.username and not parts.password,
            '平台返回了不支持的视频下载地址，请在方舟控制台下载。')


def download(app, record):
    url = record['video_url']
    valid_media_url(url)
    dest = folder(app, record['pid']) / (record['id'] + '.mp4')
    temp = dest.with_suffix('.part')
    try:
        with urllib.request.build_opener(NoRedirect()).open(url, timeout=60) as response, temp.open('wb') as f:
            length = int(response.headers.get('Content-Length', '0'))
            require(length <= MAX_VIDEO, '视频文件超过300MB，请到方舟下载')
            total = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                require(total <= MAX_VIDEO, '视频文件超过300MB')
                f.write(chunk)
        require(total > 12 and (not length or total == length), '视频下载不完整')
        with temp.open('rb') as f:
            require(f.read(12)[4:8] == b'ftyp', '下载内容不是MP4文件')
        temp.replace(dest)
    finally:
        temp.unlink(missing_ok=True)


def submit_worker(app, record, payload, key):
    marker = (record['pid'], record['id'])
    try:
        result = request(key, payload=payload)
        task_id = result.get('id', '')
        require(isinstance(task_id, str) and re.fullmatch(r'cgt-[A-Za-z0-9-]{1,120}', task_id), '未返回任务编号')
        with app.LOCK:
            record.update(task_id=task_id, status='queued', message='已提交，正在等待视频生成。')
            save_job(app, record)
    except Exception as error:
        with app.LOCK:
            rejected = isinstance(error, urllib.error.HTTPError) and 400 <= error.code < 500 and error.code != 408
            record.update(status='failed' if rejected else 'unknown', message=error_message(error) +
                          (' 未自动重试。' if rejected else ' 提交结果未确认，切勿直接重复付费提交；可从控制台找回任务编号。'))
            save_job(app, record)
    finally:
        with app.LOCK:
            ACTIVE.discard(marker)


def refresh_worker(app, record, key):
    marker = (record['pid'], record['id'])
    try:
        result = request(key, task_id=record['task_id'])
        require(result.get('id') == record['task_id'], '平台任务编号不匹配')
        state = result.get('status')
        require(state in ('queued', 'running', 'succeeded', 'failed', 'cancelled', 'expired'), '任务状态异常')
        with app.LOCK:
            record.update(status=state, message={'queued': '平台排队中', 'running': '平台生成中', 'succeeded': '生成完成，正在保存视频',
                          'failed': '平台生成失败，请到方舟任务记录查看原因；未自动重试。', 'cancelled': '任务已取消', 'expired': '任务已过期'}[state],
                          usage=result.get('usage', {}), checked=time.time())
            if state == 'succeeded':
                record['video_url'] = result.get('content', {}).get('video_url', '')
            save_job(app, record)
        if state == 'succeeded':
            download(app, record)
            with app.LOCK:
                record['message'] = '视频已保存到本机，可以预览或下载。'
                record.pop('video_url', None)
                save_job(app, record)
    except Exception as error:
        with app.LOCK:
            record['message'] = ('视频已生成，但下载未完成；点“刷新任务”重试下载，不会重新生成。' if record.get('status') == 'succeeded'
                                 else error_message(error) + ' 点“刷新任务”继续查询，不会重新生成。')
            record['checked'] = time.time()
            save_job(app, record)
    finally:
        with app.LOCK:
            ACTIVE.discard(marker)


def action(app, route, data):
    global KEY, KEY_NOTICE
    if route == '/api/video/key':
        if data.get('forget') is True:
            key_store.forget('ark'); KEY = ''; KEY_NOTICE = ''
            return {'ok': True}
        candidate = str(data.get('key', '')).strip() or KEY
        require(candidate and len(candidate) <= 4096, '请填写有效的方舟密钥')
        remember = data.get('remember', True)
        require(type(remember) is bool, '记住密钥选项无效')
        if remember:
            key_store.save(candidate, 'ark')
        else:
            key_store.forget('ark')
        KEY = candidate; KEY_NOTICE = ''
        return {'ok': True}
    pid = data.get('id')
    app.read(pid)  # project must exist
    root = folder(app, pid)
    if route == '/api/video/asset':
        return asset_add(app, pid, data)
    if route == '/api/video/draft':
        draft = data.get('draft', {})
        require(isinstance(draft, dict), '视频草稿格式无效')
        safe = {k: draft[k] for k in ('prompt', 'duration', 'resolution', 'audio', 'assets', 'episode', 'segment') if k in draft}
        require(len(json.dumps(safe)) <= 50000, '视频草稿过大')
        app.updater.save_json(root / 'draft.json', safe)
        return {'saved': True}
    if route == '/api/video/list':
        records = []
        for path in sorted((root / 'tasks').glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True):
            record = read_json(path)
            if record['status'] == 'submitting' and (pid, record['id']) not in ACTIVE:
                record.update(status='unknown', message='上次在提交过程中退出，结果未确认。请在方舟控制台核对任务编号，勿重复提交。')
                save_job(app, record)
            records.append(public_job(app, record))
        return {'jobs': records, 'assets': read_json(root / 'assets.json', []), 'draft': read_json(root / 'draft.json', {}),
                'has_key': bool(KEY), 'key_saved': key_store.location('ark').exists(), 'key_notice': KEY_NOTICE, 'model': MODEL}
    jid = data.get('job', '')
    path = job_path(app, pid, jid)
    if route == '/api/video/submit':
        if path.exists():
            return public_job(app, read_json(path))  # idempotent across HTTP retries/restarts
        require(KEY, '请先在视频设置中保存方舟密钥')
        require(data.get('paid') is True, '请确认本次会产生方舟视频费用')
        payload = make_payload(app, pid, data)
        signature = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        for old in (root / 'tasks').glob('*.json'):
            record = read_json(old)
            require(record.get('signature') != signature or record['status'] not in ('submitting', 'queued', 'running', 'unknown'),
                    '相同内容已有待完成或待核对的视频任务，请先刷新或在方舟核对，避免重复扣费。')
        record = {'id': jid, 'pid': pid, 'status': 'submitting', 'signature': signature, 'created': time.strftime('%Y-%m-%d %H:%M:%S'),
                  'prompt': data['prompt'], 'duration': payload['duration'], 'resolution': payload['resolution'], 'audio': payload['generate_audio'],
                  'assets': data.get('assets', []), 'message': '正在向方舟提交一次视频生成请求。'}
        save_job(app, record)
        ACTIVE.add((pid, jid))
        threading.Thread(target=submit_worker, args=(app, record, payload, KEY), daemon=True).start()
        return public_job(app, record)
    record = read_json(path)
    require(record, '没有找到此视频任务')
    if route == '/api/video/attach':
        require(record['status'] == 'unknown', '此任务无需找回编号')
        task_id = str(data.get('task_id', '')).strip()
        require(re.fullmatch(r'cgt-[A-Za-z0-9-]{1,120}', task_id), '平台任务编号格式无效')
        record.update(task_id=task_id, status='queued', message='已关联任务编号，请刷新查询。')
        save_job(app, record)
        return public_job(app, record)
    if route == '/api/video/refresh':
        marker = (pid, jid)
        if marker not in ACTIVE and record.get('task_id') and not public_job(app, record)['local_video']:
            require(KEY, '请先保存方舟密钥，以查询原有任务')
            if time.time() - record.get('checked', 0) >= 5:
                ACTIVE.add(marker)
                threading.Thread(target=refresh_worker, args=(app, record, KEY), daemon=True).start()
        return public_job(app, record)
    raise ValueError('未知视频操作')


def serve(handler, app):
    """Serve private local MP4s with byte ranges. URL token required by media tags."""
    parsed = urllib.parse.urlsplit(handler.path)
    query = urllib.parse.parse_qs(parsed.query)
    if query.get('token') != [app.TOKEN]:
        return handler.send({'error': '无权访问'}, status=403)
    match = re.fullmatch(r'/video/([a-f0-9]{16})/([a-f0-9]{32})\.mp4', parsed.path)
    if not match:
        return handler.send({'error': '未找到'}, status=404)
    path = folder(app, match[1]) / (match[2] + '.mp4')
    if not path.exists():
        return handler.send({'error': '视频尚未下载'}, status=404)
    size = path.stat().st_size
    start, end, status = 0, size - 1, 200
    value = handler.headers.get('Range')
    if value:
        m = re.fullmatch(r'bytes=(\d*)-(\d*)', value)
        if not m or not any(m.groups()):
            return handler.send({'error': '无效范围'}, status=416)
        start = int(m[1]) if m[1] else max(0, size - int(m[2]))
        end = min(size - 1, int(m[2])) if m[1] and m[2] else size - 1
        if not (0 <= start <= end < size):
            return handler.send({'error': '无效范围'}, status=416)
        status = 206
    handler.send_response(status)
    handler.send_header('Content-Type', 'video/mp4')
    handler.send_header('Content-Length', str(end - start + 1))
    handler.send_header('Accept-Ranges', 'bytes')
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('X-Content-Type-Options', 'nosniff')
    if query.get('download') == ['1']:
        handler.send_header('Content-Disposition', 'attachment; filename="clip-' + match[2] + '.mp4"')
    if status == 206:
        handler.send_header('Content-Range', f'bytes {start}-{end}/{size}')
    handler.end_headers()
    try:
        with path.open('rb') as f:
            f.seek(start)
            remaining = end - start + 1
            while remaining:
                chunk = f.read(min(65536, remaining))
                if not chunk:
                    break
                handler.wfile.write(chunk); remaining -= len(chunk)
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
        pass
