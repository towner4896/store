"""Durable, independent UI checkpoints; never submit text to AI."""
import json
import re
import secrets
import time


def action(app, route, data):
    folder=app.DATA/'ui-drafts'
    folder.mkdir(parents=True,exist_ok=True)
    if route=='/api/drafts/save':
        value=data.get('snapshot')
        app.require(isinstance(value,dict),'草稿格式错误')
        allowed={'project_id','revision','tab','number','dirty','fields','partnerInputs','partnerNotes','ideaDrafts','instruction','forms','view','video'}
        app.require(set(value)<=allowed,'草稿包含不支持的字段')
        app.require(len(json.dumps(value,ensure_ascii=False).encode())<=4*1024*1024,'草稿过大，请先保存作品')
        ident=secrets.token_hex(12)
        record={'id':ident,'created':time.strftime('%Y-%m-%d %H:%M:%S'),'snapshot':value,'restored':False}
        app.updater.save_json(folder/(ident+'.json'),record)
        return {'id':ident,'saved':True}
    if route=='/api/drafts/list':
        records=[json.loads(p.read_text('utf-8')) for p in sorted(folder.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)]
        return {'drafts':[{'id':r['id'],'created':r['created']} for r in records if not r.get('restored')]}
    ident=data.get('id','')
    app.require(isinstance(ident,str) and re.fullmatch('[a-f0-9]{24}',ident),'草稿编号无效')
    path=folder/(ident+'.json')
    record=json.loads(path.read_text('utf-8'))
    if route=='/api/drafts/get':return record
    if route=='/api/drafts/restored':
        record['restored']=True;app.updater.save_json(path,record);return {'ok':True}
    raise ValueError('未知草稿操作')
