"""Per-Windows-user DPAPI secret storage outside application/update folders."""
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import tempfile


def location(provider='deepseek'):
    if provider not in ('deepseek', 'ark'):
        raise ValueError('未知密钥类型')
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'ReXueStudio' / 'credentials' / (provider + '.dpapi')


def transform(data, decrypt=False):
    if os.name != 'nt':
        raise ValueError('记住密钥需要 Windows；可以取消勾选，仅本次使用。')
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]
    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    output = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    fn = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    fn.restype = wintypes.BOOL
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    if not fn(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(output)):
        raise ValueError('Windows 无法读取已保存的密钥，请在设置中重新保存。' if decrypt else 'Windows 加密密钥失败，原有保存未变动。')
    try:
        return ctypes.string_at(output.data, output.size)
    finally:
        kernel.LocalFree(ctypes.cast(output.data, ctypes.c_void_p))


def load(provider='deepseek'):
    p = location(provider)
    if not p.exists():
        return '', ''
    try:
        raw = p.read_bytes()
        if len(raw) > 65536:
            raise ValueError('密钥文件异常')
        return transform(raw, True).decode('utf-8'), ''
    except Exception:
        return '', '已保存的密钥无法解密，请重新输入并保存。'


def save(key, provider='deepseek'):
    encrypted = transform(key.encode('utf-8'))
    p = location(provider)
    p.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile(dir=p.parent, delete=False) as f:
            name = f.name
            f.write(encrypted)
        os.replace(name, p)
    finally:
        if name and Path(name).exists():
            Path(name).unlink()


def forget(provider='deepseek'):
    location(provider).unlink(missing_ok=True)
