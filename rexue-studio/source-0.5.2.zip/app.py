"""本地短剧写作工具。Python 3.10+，仅使用标准库。"""
import copy
import io
import json
import os
import re
import secrets
import threading
import time
import urllib.request
import urllib.error
import webbrowser
import zipfile
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from xml.etree import ElementTree as ET
import workflow
import ideas
import partner
import updater
import sys

ROOT = Path(__file__).resolve().parent
DATA = (Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'ReXueStudio' / 'data') if getattr(sys, 'frozen', False) else ROOT / 'data'
LOCK = threading.RLock()
TOKEN = secrets.token_urlsafe(32)
KEY = os.environ.get('DEEPSEEK_API_KEY', '')
JOBS = {}
FIELDS = {'assets':'人物道具场景', 'action':'完整动作与对白', 'storyboard':'故事板提示词', 'video':'视频提示词', 'voice':'本段音色', 'continuity':'首尾帧与连续性'}
RULES = '固定16:9；每集100秒、10段，每段10秒。每段三个镜头按0—3秒、3—7秒、7—10秒推进；九宫格每行是同一镜头的开始、进行、结束，不能写成九个镜头。保持既定人物形象、音色、道具归属和场景空间。同场末帧接下段首帧，换场重新建立空间。对白自然语速，预留反应时间。仅指定角色开口，画外音不让画内人物对口型。无字幕、文字、水印、背景音乐和新增旁白；保留指定对白及环境动作声。@资产名称需要用户在小云雀手动绑定。'

def dump(x):
    return json.dumps(x, ensure_ascii=False, indent=2)

def require(ok, message):
    if not ok:
        raise ValueError(message)

def path(pid):
    require(isinstance(pid, str) and re.fullmatch(r'[a-f0-9]{16}', pid), '项目编号无效')
    return DATA / (pid + '.json')

def read(pid):
    return workflow.migrate(json.loads(path(pid).read_text('utf-8')))

def write(p, snapshot=True):
    DATA.mkdir(exist_ok=True)
    target = path(p['id'])
    if target.exists() and snapshot:
        history = DATA / 'history' / p['id']
        history.mkdir(parents=True, exist_ok=True)
        (history / f'{time.time_ns()}.json').write_bytes(target.read_bytes())
        for old in sorted(history.glob('*.json'))[:-30]:
            old.unlink()
    p['revision'] = p.get('revision', 0) + 1
    p['updated'] = time.strftime('%Y-%m-%d %H:%M:%S')
    temp = target.with_suffix('.tmp')
    temp.write_text(dump(p), 'utf-8')
    temp.replace(target)

def text(value, name):
    require(isinstance(value, str) and value.strip(), name + '不能为空')

def validate_outline(o, p):
    workflow.validate_outline(o, p)

def validate_episode(e):
    require(isinstance(e, dict), '剧本格式错误')
    for k in ('title','plot','continuity','asset_prep'):
        text(e.get(k), k)
    require(isinstance(e.get('segments'), list) and len(e['segments']) == 10, '制作表必须恰好10段')
    for i, s in enumerate(e['segments'], 1):
        for k in FIELDS:
            text(s.get(k), f'第{i}段{FIELDS[k]}')

def stale(p, start=1):
    workflow.stale(p, start)

def new_project(d):
    for k in ('title','idea','genre','style'):
        text(d.get(k), k)
    target = int(d.get('target_episodes', 90))
    chapters = int(d.get('chapter_count', 40))
    words = int(d.get('chapter_words', 2000))
    require(90 <= target <= 180, '短剧目标集数支持90—180集')
    require(10 <= chapters <= 120, '小说章节数支持10—120章')
    require(1000 <= words <= 5000, '每章目标字数支持1000—5000字')
    return dict(schema_version=2, target_episodes=target, chapter_count=chapters, chapter_words=words, novel_confirmed=False, adaptation=None, adaptation_approved=False, id=secrets.token_hex(8), revision=0, title=d['title'], idea=d['idea'], genre=d['genre'], style=d['style'], outline=None, approved=False, chapters={}, scripts={}, usage=[], budget=50.0, demo=False)

def generate_prompt(p, kind, n, instruction):
    return workflow.generate_prompt(p, kind, n, instruction, RULES)


def run_job(jid, p, kind, n, instruction, key):
    job = JOBS[jid]
    try:
        payload = {'model':'deepseek-flash','messages':generate_prompt(p, kind, n, instruction), 'response_format':{'type':'json_object'}, 'thinking':{'type':'disabled'}, 'max_tokens':32000 if kind in ('outline','adaptation') else 20000, 'temperature':0.85}
        req = urllib.request.Request('https://api.deepseek.com/chat/completions', data=dump(payload).encode(), headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        with urllib.request.urlopen(req, timeout=600) as response:
            result = json.load(response)
        usage = result.get('usage', {})
        # Conservative estimate: peak price and no cache discount, not an actual bill.
        cost = (usage.get('prompt_tokens',0)*2 + usage.get('completion_tokens',0)*8)/1000000
        with LOCK:
            current = read(p['id'])
            current['usage'].append({'time':time.strftime('%Y-%m-%d %H:%M'), 'kind':kind, 'number':n, 'input':usage.get('prompt_tokens',0), 'output':usage.get('completion_tokens',0), 'estimate':cost, 'usage_available':bool(usage)})
            write(current)
        choice = result['choices'][0]
        raw = choice['message']['content']
        # Retain incomplete/schema-invalid responses for recovery, without API credentials.
        recovery = DATA / 'recovery'
        recovery.mkdir(exist_ok=True)
        (recovery / (jid+'.txt')).write_text(raw, 'utf-8')
        require(choice.get('finish_reason') == 'stop', '生成未完整结束。已记录返回用量并保留原文，请缩短要求后手动重试。')
        value = json.loads(raw)
        if kind == 'outline':
            validate_outline(value, p)
        elif kind == 'adaptation':
            workflow.validate_adaptation(value, p)
        elif kind == 'chapter':
            for k in ('title','text','summary'):
                text(value.get(k), k)
        else:
            validate_episode(value)
        with LOCK:
            current = read(p['id'])
            require(current['revision'] == p['revision']+1, '生成期间项目被修改，结果保存在data/recovery，请勿覆盖新版本。')
            if kind == 'outline':
                current['outline'] = value
                current['approved'] = False
                stale(current)
            elif kind == 'adaptation':
                value['stale'] = False
                current['adaptation'] = value
                current['adaptation_approved'] = False
                for v in current['scripts'].values():
                    v['stale'] = True
            else:
                value['stale'] = False
                if kind == 'chapter':
                    stale(current, n)
                    current['chapters'][str(n)] = value
                    if isinstance(value.get('self_review'), str) and value['self_review'].strip():
                        partner.ensure(current, n)['messages'].append({'role':'assistant','text':'本章写作自检：\n'+value['self_review'],'questions':[]})
                else:
                    for k,v in current['scripts'].items():
                        if int(k)>n:
                            v['stale']=True
                    current['scripts'][str(n)] = value
            write(current)
        job.update(status='done', message='已生成并保存。请检查内容后继续。')
    except urllib.error.HTTPError as e:
        hints = {401:'API密钥无效，请检查设置。',402:'API余额不足。',429:'接口繁忙或限流，请稍后手动重试。'}
        job.update(status='error', message=hints.get(e.code, f'接口返回HTTP {e.code}，未自动重试。'))
    except Exception as e:
        job.update(status='error', message=str(e)[:400]+'；未自动重试，已有内容已保留。网络中断时请核对平台账单。')

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
ET.register_namespace('w', W[1:-1])

def set_text(node, value):
    """Replace a paragraph or cell while retaining source typography."""
    if node.tag == W+'tc':
        sample = node.find(W+'p')
        for child in list(node):
            if child.tag != W+'tcPr':
                node.remove(child)
        paragraph = copy.deepcopy(sample) if sample is not None else ET.Element(W+'p')
        node.append(paragraph)
    else:
        paragraph = node
    rp = paragraph.find('.//'+W+'rPr')
    rp = copy.deepcopy(rp) if rp is not None else None
    for child in list(paragraph):
        if child.tag != W+'pPr':
            paragraph.remove(child)
    run = ET.SubElement(paragraph, W+'r')
    if rp is not None:
        run.append(rp)
    for i, line in enumerate(str(value).split('\n')):
        if i:
            ET.SubElement(run, W+'br')
        t = ET.SubElement(run, W+'t', {'{http://www.w3.org/XML/1998/namespace}space':'preserve'})
        t.text = line

def export_docx(p, n):
    e = p['scripts'][str(n)]
    validate_episode(e)
    with zipfile.ZipFile(ROOT/'templates/reference.docx') as z:
        parts = {name:z.read(name) for name in z.namelist()}
    tree = ET.fromstring(parts['word/document.xml'])
    body = tree.find(W+'body')
    original = list(body)
    paragraphs = [x for x in original if x.tag==W+'p']
    tables = [x for x in original if x.tag==W+'tbl']
    sect = copy.deepcopy(body.find(W+'sectPr'))
    for child in list(body):
        body.remove(child)
    def para(index, value):
        v = copy.deepcopy(paragraphs[index]); set_text(v, value); body.append(v)
    para(0, f'{p["title"]} 第{n:02d}集 {e["title"]}')
    para(1, '小云雀10秒分段制作表')
    para(2, f'本集10段，每段10秒，合计100秒。16:9，{p["style"]}。正常语速，不倍速、不抢台词。')
    para(3, '剧情对应'); para(4, e['plot'])
    para(3, '生成规则'); para(4, RULES)
    para(3, '重要连续性'); para(4, e['continuity'])
    para(3, '资产准备')
    t = copy.deepcopy(tables[0]); rows=t.findall(W+'tr')
    for row in rows[2:]: t.remove(row)
    for cell,value in zip(rows[0].findall(W+'tc'), ['字段','可复制提示词']): set_text(cell,value)
    for cell,value in zip(rows[1].findall(W+'tc'), ['本集资产',e['asset_prep']]): set_text(cell,value)
    body.append(t)
    segment_template = next(t for t in tables if len(t.findall(W+'tr')[0].findall(W+'tc'))==3)
    for start in range(0,10,2):
        para(3, f'第{n}集 第{start+1:02d}至{start+2:02d}段')
        t=copy.deepcopy(segment_template)
        rows=t.findall(W+'tr')
        values=[['字段']+[f'第{n}集 第{i+1:02d}段\n{i*10}至{(i+1)*10}秒' for i in (start,start+1)]]
        values += [[label,e['segments'][start][key],e['segments'][start+1][key]] for key,label in FIELDS.items()]
        for row, vals in zip(rows, values):
            for cell, val in zip(row.findall(W+'tc'),vals): set_text(cell,val)
        body.append(t)
    body.append(sect)
    parts['word/document.xml']=ET.tostring(tree,encoding='utf-8',xml_declaration=True)
    # Remove source-specific core metadata.
    if 'docProps/core.xml' in parts:
        core=ET.fromstring(parts['docProps/core.xml'])
        for element in core: element.text=''
        parts['docProps/core.xml']=ET.tostring(core,encoding='utf-8',xml_declaration=True)
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        for name,content in parts.items(): z.writestr(name,content)
    return output.getvalue()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_): pass
    def send(self, body, content='application/json; charset=utf-8', status=200, filename=None):
        if not isinstance(body,bytes): body=dump(body).encode('utf-8')
        self.send_response(status); self.send_header('Content-Type',content)
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        if filename: self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
    def valid_host(self):
        return self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'
    def do_GET(self):
        if not self.valid_host(): return self.send({'error':'仅允许本机访问'},status=403)
        if self.path=='/':
            return self.send((ROOT/'index.html').read_text('utf-8').replace('__TOKEN__',TOKEN).encode(),'text/html; charset=utf-8')
        self.send({'error':'未找到'},status=404)
    def do_POST(self):
        global KEY
        if not self.valid_host() or self.headers.get('X-Local-Token')!=TOKEN:
            return self.send({'error':'请从本机工作台页面操作'},status=403)
        try:
            size=int(self.headers.get('Content-Length','0')); require(0<size<=10000000,'请求过大')
            d=json.loads(self.rfile.read(size))
            with LOCK:
                result=self.action(self.path,d)
            if isinstance(result,bytes):
                return self.send(result,'application/vnd.openxmlformats-officedocument.wordprocessingml.document',filename=f'episode-{d["number"]:02d}.docx')
            self.send(result)
        except Exception as e:
            self.send({'error':str(e)[:500]},status=400)
    def action(self, route, d):
        global KEY
        if route.startswith('/api/update/'):
            return updater.action(sys.modules[__name__], self.server, route, d)
        require(updater.STATE['status']!='installing','正在升级，请等待新版本自动打开。')
        if route.startswith('/api/ideas/'):
            return ideas.action(sys.modules[__name__], route, d)
        if route=='/api/list':
            DATA.mkdir(exist_ok=True)
            return {'projects':[{'id':p['id'],'title':p['title'],'updated':p['updated']} for f in sorted(DATA.glob('*.json'),key=lambda f:f.stat().st_mtime,reverse=True) for p in [json.loads(f.read_text('utf-8'))]],'has_key':bool(KEY)}
        if route=='/api/key':
            KEY=str(d.get('key','')).strip(); return {'ok':True}
        if route=='/api/create':
            p=new_project(d); write(p); return p
        if route=='/api/job': return JOBS.get(d['job'],{'status':'error','message':'任务已丢失，请检查项目与平台账单。'})
        p=read(d['id'])
        if route=='/api/get': return p
        if route=='/api/docx':
            workflow.check_ready(p, 'script', int(d['number']))
            require(not p['scripts'][str(d['number'])].get('stale'), '本集内容待复核，请先保存或重新生成。')
            return export_docx(p,int(d['number']))
        require(not any(j['pid']==p['id'] and j['status']=='running' for j in JOBS.values()),'项目正在生成，请等待完成再编辑。')
        require(d.get('revision')==p['revision'],'项目已有更新，请重新打开项目。')
        if route.startswith('/api/partner/'):
            return partner.action(sys.modules[__name__], route, d, p)
        if route=='/api/approve':
            validate_outline(p['outline'], p); p['approved']=True
        elif route=='/api/finish-novel':
            require(workflow.novel_complete(p), '请完成并复核全部小说章节，再确认完稿。')
            p['novel_confirmed'] = True
        elif route=='/api/approve-adaptation':
            workflow.check_ready(p, 'adaptation', 1)
            workflow.validate_adaptation(p['adaptation'], p)
            require(p['adaptation']['sufficient'] and not p['adaptation'].get('stale'), '故事容量不足或方案已过期，请先补充小说，再重新拆集。')
            p['adaptation_approved'] = True
        elif route=='/api/budget':
            budget=float(d['budget']); require(0<budget<=100000,'预算必须大于0'); p['budget']=budget
        elif route=='/api/save':
            kind=d['kind']; value=d['value']; n=int(d.get('number',1))
            require(1 <= n <= (p['chapter_count'] if kind=='chapter' else p['target_episodes']), '章节或集数超出范围')
            if kind=='outline':
                validate_outline(value, p); p['outline']=value; p['approved']=False; stale(p)
            elif kind=='chapter':
                workflow.check_ready(p, kind, n)
                for k in ('title','text','summary'): text(value.get(k), k)
                stale(p,n); value['stale']=False; p['chapters'][str(n)]=value
            elif kind=='adaptation':
                workflow.check_ready(p, kind, 1)
                workflow.validate_adaptation(value, p)
                value['stale'] = False
                p['adaptation'] = value
                p['adaptation_approved'] = False
                for v in p['scripts'].values():
                    v['stale'] = True
            elif kind=='script':
                workflow.check_ready(p, kind, n)
                validate_episode(value)
                for k,v in p['scripts'].items():
                    if int(k)>n: v['stale']=True
                value['stale']=False; p['scripts'][str(n)]=value
            else: raise ValueError('未知内容类型')
        elif route=='/api/generate':
            require(KEY,'请先在设置中填入DeepSeek API密钥。')
            require(sum(x['estimate'] for x in p['usage'])<p['budget'],'已达到项目预算提醒阈值，请先核对账单并调整预算。')
            kind=d['kind']; n=int(d.get('number',1))
            workflow.check_ready(p, kind, n)
            jid=secrets.token_hex(8)
            JOBS[jid]={'status':'running','message':'AI正在写作，通常需要数分钟。请勿重复提交。','pid':p['id']}
            threading.Thread(target=run_job,args=(jid,copy.deepcopy(p),kind,n,str(d.get('instruction','')),KEY),daemon=True).start()
            return {'job':jid}
        else: raise ValueError('未知操作')
        write(p); return p

def main():
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    url=f'http://127.0.0.1:{server.server_port}'
    if '--update-health' in sys.argv:
        health=Path(sys.argv[sys.argv.index('--update-health')+1])
        updater.save_json(health,{'version':updater.VERSION,'url':url,'token':sys.argv[sys.argv.index('--update-token')+1],'pid':os.getpid()})
    print('热血短剧工作台已启动：'+url+'\n请保留此窗口；关闭窗口后服务停止。',flush=True)
    if '--no-browser' not in __import__('sys').argv: webbrowser.open(url)
    try:server.serve_forever()
    finally:server.server_close()

if __name__=='__main__': main()
