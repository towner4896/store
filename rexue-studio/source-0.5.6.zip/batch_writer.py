"""Sequential chapter production with durable per-chapter saves and stop control."""
import copy
import secrets
import threading


def action(app, route, data, p):
    active=next(((jid,j) for jid,j in app.JOBS.items() if j.get('pid')==p['id'] and j.get('batch') and j['status']=='running'),None)
    if route=='/api/batch/status':
        return {'job':active[0],'state':copy.deepcopy(active[1])} if active else {'job':None}
    if route=='/api/batch/stop':
        app.require(active,'当前没有正在生成的批次')
        active[1]['stop_requested']=True
        active[1]['message']='正在完成并保存当前章节，之后停止。'
        return {'ok':True}
    app.require(route=='/api/batch/start','未知批量操作')
    app.require(not any(j.get('pid')==p['id'] and j['status']=='running' for j in app.JOBS.values()),'项目正在生成，请等待结束')
    app.require(data.get('revision')==p['revision'],'项目已有更新，请重新打开项目')
    app.require(app.KEY,'请先设置API密钥')
    app.require(p['approved'],'请先确认小说大纲')
    app.validate_outline(p['outline'],p)
    start=int(data.get('start',1));end=int(data.get('end',p['chapter_count']))
    app.require(1<=start<=end<=p['chapter_count'],'章节范围无效')
    overwrite=data.get('overwrite',False)
    app.require(type(overwrite) is bool,'覆盖选项无效')
    app.workflow.check_ready(p,'chapter',start)
    app.require(sum(u['estimate'] for u in p['usage'])<p['budget'],'已达到项目预算提醒阈值，请先核对账单')
    instruction=str(data.get('instruction','')).strip()
    app.require(len(instruction)<=12000,'写作要求过长')
    jid=secrets.token_hex(8)
    app.JOBS[jid]={'pid':p['id'],'batch':True,'status':'running','message':'批量写作准备中','start':start,'end':end,'current':start,'completed':0,'skipped':0,'stop_requested':False}
    threading.Thread(target=run,args=(app,jid,start,end,overwrite,instruction,app.KEY),daemon=True).start()
    return {'job':jid}


def run(app,jid,start,end,overwrite,instruction,key):
    job=app.JOBS[jid]
    try:
        for n in range(start,end+1):
            with app.LOCK:
                if job['stop_requested']:
                    job.update(status='stopped',message=f'已停止，已生成并保存{job["completed"]}章。再次开始会跳过已有有效章节。');return
                p=app.read(job['pid'])
                existing=p['chapters'].get(str(n))
                if existing and not overwrite:
                    app.require(not existing.get('stale'),f'第{n}章因前文变更待复核。请复核保存，或勾选覆盖后从此章继续。')
                    job['skipped']+=1;continue
                app.require(sum(u['estimate'] for u in p['usage'])<p['budget'],'已达到预算提醒阈值，已停止继续调用。已完成的章节保留。')
                app.workflow.check_ready(p,'chapter',n)
                job.update(current=n,message=f'正在写第{n}章（本批{start}—{end}章），已保存{job["completed"]}章')
                child=secrets.token_hex(8)
                app.JOBS[child]={'pid':p['id'],'status':'running','message':'批量章节写作中'}
            app.run_job(child,copy.deepcopy(p),'chapter',n,instruction,key)
            with app.LOCK:
                result=app.JOBS.pop(child)
                app.require(result['status']=='done',f'第{n}章未完成：'+result.get('message','生成失败'))
                job['completed']+=1;job['last_completed']=n
        job.update(status='done',message=f'批量完成：生成并保存{job["completed"]}章，跳过{job["skipped"]}章。请直接阅读正文。')
    except Exception as e:
        job.update(status='error',message=str(e)[:500]+' 已完成章节保留，未自动重试。')
