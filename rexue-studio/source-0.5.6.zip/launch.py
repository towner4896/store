"""Windows launcher with persistent startup diagnostics."""
import datetime
import os
from pathlib import Path
import sys
import traceback


def main():
    root = Path(__file__).resolve().parent
    frozen = getattr(sys, 'frozen', False)
    log_root = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'ReXueStudio' if frozen else root
    log_root.mkdir(parents=True, exist_ok=True)
    log = log_root / 'startup.log'
    try:
        os.chdir(str(root))
        # A running source edition keeps its current UI until the next launch.
        pending_ui = root / 'index.pending.html'
        if not frozen and pending_ui.exists():
            pending_ui.replace(root / 'index.html')
        with log.open('a', encoding='utf-8') as stream:
            stream.write('\nStarted: ' + datetime.datetime.now().isoformat() + '\n')
            stream.write('Python: ' + sys.version + '\n')
        if sys.version_info < (3, 10):
            raise RuntimeError('Python 3.10 or newer is required. Please update Python.')
        required = ('index.html', 'templates/reference.docx') if frozen else ('app.py', 'workflow.py', 'ideas.py', 'partner.py', 'updater.py', 'index.html', 'templates/reference.docx')
        for name in required:
            if not (root / name).is_file():
                raise RuntimeError('Missing file: ' + name + '. Extract the entire ZIP before starting.')
        import app
        if frozen:
            print('作品保存位置：' + str(app.DATA), flush=True)
        if '--check' in sys.argv:
            print('Startup check passed: Python, application modules, interface and template are available.')
            return 0
        app.main()
        return 0
    except KeyboardInterrupt:
        print('\nApplication stopped.')
        return 0
    except Exception:
        error = traceback.format_exc()
        print(error)
        try:
            with log.open('a', encoding='utf-8') as stream:
                stream.write(error)
            print('Startup failed. Details saved to: ' + str(log))
        except OSError:
            print('Could not write startup.log. Copy the error above.')
        return 1


if __name__ == '__main__':
    sys.exit(main())
