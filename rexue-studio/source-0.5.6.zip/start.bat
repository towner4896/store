@echo off
setlocal
chcp 65001 >nul
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"
if not exist "%~dp0launch.py" goto missing_files
where py >nul 2>nul
if not errorlevel 1 goto run_py
where python >nul 2>nul
if not errorlevel 1 goto run_python
echo Python was not found. Install Python 3.10 or newer.
echo Download: https://www.python.org/downloads/windows/
echo During installation, enable "Add Python to PATH".
set "APP_EXIT=1"
goto done
:run_py
py -3 "%~dp0launch.py" %*
set "APP_EXIT=%errorlevel%"
goto done
:run_python
python "%~dp0launch.py" %*
set "APP_EXIT=%errorlevel%"
goto done
:missing_files
echo Missing launch.py. Extract the entire ZIP, then run start.bat.
set "APP_EXIT=1"
:done
if "%~1"=="--check" exit /b %APP_EXIT%
echo.
echo The application has stopped. If it failed, check startup.log in this folder.
pause
exit /b %APP_EXIT%
