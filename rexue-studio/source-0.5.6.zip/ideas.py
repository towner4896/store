"""可筛选、逐轮修改并转成小说项目的选题库。"""
import copy
import json
import secrets
import time
import urllib.request
import urllib.error

FIELDS = {'title':'作品名', 'genre':'题材', 'logline':'一句话故事', 'protagonist':'主角与成长', 'conflict':'核心冲突', 'arcs':'阶段剧情', 'highlights':'看点与差异', 'ending':'结局方向', 'capacity':'90集以上的剧情容量与风险', 'production':'制作难度与建议', 'style':'画面风格'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(app):
    file = app.DATA / 'ideas' / 'state.json'
    if file.exists():
        return json.loads(file.read_text('utf-8'))
    return {'revision':0,'candidates':[],'usage':[],'budget':10.0,'preferences':{'genre':'让AI推荐不同题材','style':'让AI建议','target_episodes':90,'notes':''}}


def write(app, state):
    directory=app.DATA/'ideas';directory.mkdir(parents=True,exist_ok=True)
    target=directory/'state.json'
    if target.exists():
        history=directory/'history';history.mkdir(exist_ok=True)
        (history/f'{time.time_ns()}.json').write_bytes(target.read_bytes())
        for old in sorted(history.glob('*.json'))[:-30]:old.unlink()
    state['revision']+=1
    temp=target.with_suffix('.tmp');temp.write_text(app.dump(state),'utf-8');temp.replace(target)


def candidate(state, cid):
    found=next((c for c in state['candidates'] if c['id']==cid),None)
    require(found is not None,'找不到这个选题，请刷新选题库。')
    return found


def validate(value):
    require(isinstance(value,dict),'推荐格式错误')
    for k,label in FIELDS.items():
        require(isinstance(value.get(k),str) and value[k].strip(),f'推荐中缺少{label}')


def prompt(state, cid, feedback):
    system='你是原创热血小说策划。只返回JSON。推荐的是故事创作方案，不是市场销量预测；不要声称实时热门、保证爆款或保证能拍够集数。用户先筛选，再提意见，满意后才写小说大纲。方案要有完整故事逻辑与结局，适合16:9、每集100秒的AI短剧。'
    context={'preferences':state['preferences']}
    schema='每个方案必须包含这些非空字符串字段：'+ '；'.join(k+'：'+v for k,v in FIELDS.items())+'。每个方案约500—800汉字。capacity应写具体的阶段冲突、事件群及拖戏风险，不能仅根据字数推算。production说明角色、场景、群战和特效给新人造成的难度。'
    if cid:
        c=candidate(state,cid)
        context={'preferences':c['preferences'],'selected_proposal':c['proposal'],'previous_feedback':[v.get('feedback','') for v in c['versions'] if v.get('feedback')],'current_feedback':feedback}
        task='只修改选中的一个方案。保留用户认可的核心设定，落实本次意见并兼顾此前意见；若意见冲突以最新明确意见为准。不要替换成另一个无关故事。返回{"proposal":{...},"changes":"说明本次具体改了什么，有何取舍"}。'+schema
    else:
        context['previous_options']=[{'title':c['proposal']['title'],'logline':c['proposal']['logline'],'status':c['status']} for c in state['candidates'][-40:]]
        task='一次推荐恰好4个明显不同的原创故事方案。用户可以完全没有灵感；偏好空白时主动提供不同题材、主角目标与冲突。遵守不喜欢的内容和制作限制。避开已淘汰方案的重复设定，不照搬已选方案。根据preferences.target_episodes规划至少相应集数的潜力。返回{"proposals":[方案1,方案2,方案3,方案4]}。'+schema
    return [{'role':'system','content':system},{'role':'user','content':task+'\n用户资料：\n'+json.dumps(context,ensure_ascii=False)}]


def run(app, jid, snapshot, cid, feedback, key):
    try:
        payload={'model':'deepseek-flash','messages':prompt(snapshot,cid,feedback),'response_format':{'type':'json_object'},'thinking':{'type':'disabled'},'max_tokens':14000,'temperature':0.9}
        req=urllib.request.Request('https://api.deepseek.com/chat/completions',data=app.dump(payload).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=600) as response:result=json.load(response)
        u=result.get('usage',{});cost=(u.get('prompt_tokens',0)*2+u.get('completion_tokens',0)*8)/1000000
        with app.LOCK:
            state=read(app);state['usage'].append({'time':time.strftime('%Y-%m-%d %H:%M'),'kind':'refine' if cid else 'recommend','input':u.get('prompt_tokens',0),'output':u.get('completion_tokens',0),'estimate':cost,'usage_available':bool(u)});write(app,state)
        choice=result['choices'][0];raw=choice['message']['content']
        recovery=app.DATA/'ideas'/'recovery';recovery.mkdir(exist_ok=True);(recovery/(jid+'.txt')).write_text(raw,'utf-8')
        require(choice.get('finish_reason')=='stop','推荐未完整生成，原文已保留。')
        value=json.loads(raw)
        if cid:
            validate(value.get('proposal'));require(isinstance(value.get('changes'),str) and value['changes'].strip(),'缺少修改说明')
        else:
            require(isinstance(value.get('proposals'),list) and len(value['proposals'])==4,'AI必须返回4个方案')
            for proposal in value['proposals']:validate(proposal)
        with app.LOCK:
            state=read(app)
            require(state['revision']==snapshot['revision']+1,'选题库已变更，结果已保存在ideas/recovery，未覆盖新版本。')
            if cid:
                c=candidate(state,cid);c['proposal']=value['proposal'];c['changes']=value['changes'];c['version']+=1
                c['versions'].append({'version':c['version'],'proposal':copy.deepcopy(c['proposal']),'feedback':feedback,'changes':c['changes']})
            else:
                for p in value['proposals']:
                    state['candidates'].append({'id':secrets.token_hex(8),'proposal':p,'preferences':copy.deepcopy(snapshot['preferences']),'status':'new','version':1,'changes':'初始推荐','versions':[{'version':1,'proposal':copy.deepcopy(p),'feedback':'','changes':'初始推荐'}],'adopted':{}})
            write(app,state)
        app.JOBS[jid].update(status='done',message='选中方案已按意见修改，原版本保留。' if cid else '已推荐4个新方案，可以筛选并提出修改意见。')
    except urllib.error.HTTPError as e:
        app.JOBS[jid].update(status='error',message={401:'API密钥无效，请检查设置。',402:'API余额不足。',429:'接口繁忙，请稍后重试。'}.get(e.code,f'API返回HTTP {e.code}。')+' 未自动重试。')
    except Exception as e:
        app.JOBS[jid].update(status='error',message=str(e)[:350]+' 已有方案保留；未自动重试，请核对平台账单。')


def action(app, route, data):
    state=read(app)
    if route=='/api/ideas/get':
        active=next((jid for jid,j in app.JOBS.items() if j['pid']=='ideas' and j['status']=='running'),None)
        return {**state,'active_job':active}
    require(not any(j['pid']=='ideas' and j['status']=='running' for j in app.JOBS.values()),'选题正在生成，请稍后操作。')
    require(data.get('revision')==state['revision'],'选题库已有更新，请重新打开AI推荐选题。')
    if route=='/api/ideas/mark':
        c=candidate(state,data.get('candidate'))
        require(data.get('status') in ('new','shortlist','pass'),'筛选状态无效')
        c['status']=data['status'];write(app,state);return state
    if route=='/api/ideas/adopt':
        c=candidate(state,data.get('candidate'));require(c['status']=='shortlist','请先将方案选入候选。')
        previous=c['adopted'].get(str(c['version']))
        if previous and app.path(previous).exists():return {'project':app.read(previous)}
        p=c['proposal']
        idea='\n\n'.join(f'{label}：{p[k]}' for k,label in FIELDS.items() if k not in ('title','genre','style'))
        project=app.new_project({'title':p['title'],'idea':idea,'genre':p['genre'],'style':p['style'],'target_episodes':c['preferences']['target_episodes'],'chapter_count':40,'chapter_words':2000})
        project['selected_proposal']={'candidate':c['id'],'version':c['version'],'proposal':copy.deepcopy(p),'feedback_history':[v['feedback'] for v in c['versions'] if v.get('feedback')]}
        app.write(project);c['adopted'][str(c['version'])]=project['id'];write(app,state)
        return {'project':project}
    if route=='/api/ideas/generate':
        require(app.KEY,'请先在AI设置中填入API密钥。')
        cid=data.get('candidate');feedback=str(data.get('feedback','')).strip()
        if cid:
            require(candidate(state,cid)['status']=='shortlist','请先选入候选，再提出修改意见。')
            require(feedback,'请填写你想修改的地方。')
        else:
            prefs=data.get('preferences',{});target=int(prefs.get('target_episodes',90))
            require(90<=target<=180,'目标集数支持90—180集')
            state['preferences']={'genre':str(prefs.get('genre','')).strip() or '让AI推荐不同题材','style':str(prefs.get('style','')).strip() or '让AI建议','notes':str(prefs.get('notes','')),'target_episodes':target}
        budget=float(data.get('budget',state['budget']));require(0<budget<=100000,'选题预算必须大于0')
        state['budget']=budget
        require(sum(u['estimate'] for u in state['usage'])<budget,'选题累计估算已达到提醒阈值，请调整选题预算。')
        write(app,state)
        jid=secrets.token_hex(8);app.JOBS[jid]={'pid':'ideas','status':'running','message':'AI正在策划故事方案。'}
        __import__('threading').Thread(target=run,args=(app,jid,copy.deepcopy(state),cid,feedback,app.KEY),daemon=True).start()
        return {'job':jid}
    raise ValueError('未知选题操作')
