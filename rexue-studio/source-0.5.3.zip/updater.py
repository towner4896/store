"""Verified update downloads and an out-of-process transactional installer."""
import copy
import ctypes
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import shutil
import stat
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import zipfile

VERSION='0.5.3'
DEFAULT_CHANNEL='https://raw.githubusercontent.com/towner4896/store/master/rexue-studio/channel.json'
APP_ID='rexue-studio'
STATE={'status':'idle','message':'尚未检查更新。'}
GUARD=threading.RLock()
MAX_ZIP=150*1024*1024
MAX_EXPANDED=600*1024*1024

def require(ok,message):
    if not ok:raise ValueError(message)

def version(s):
    require(isinstance(s,str) and re.fullmatch(r'\d+\.\d+\.\d+',s),'版本号必须为三段数字')
    return tuple(map(int,s.split('.')))

def install_root(app):
    return Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else app.ROOT.resolve()

def mode():return 'windows-x64' if getattr(sys,'frozen',False) else 'source'

def state_dir(root):
    digest=hashlib.sha256(str(root).lower().encode()).hexdigest()[:16]
    return Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'ReXueStudio'/'updates'/digest

def save_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),'utf-8');temp.replace(path)

def settings(root):
    p=state_dir(root)/'config.json'
    value=json.loads(p.read_text('utf-8')) if p.exists() else {}
    return {**value,'channel':value.get('channel') or DEFAULT_CHANNEL}

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        require(urllib.parse.urlsplit(newurl).scheme=='https','更新下载禁止降级到非HTTPS地址')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def open_resource(location):
    if str(location).startswith('https://'):
        parsed=urllib.parse.urlsplit(location)
        require(parsed.hostname and not parsed.username and not parsed.password,'更新地址不能包含账号密码')
        return urllib.request.build_opener(SafeRedirect()).open(urllib.request.Request(location,headers={'User-Agent':'ReXueStudio-Updater/'+VERSION}),timeout=30)
    require(not urllib.parse.urlsplit(str(location)).scheme or Path(location).is_absolute(),'只接受HTTPS或本机绝对路径')
    p=Path(location);require(p.is_absolute() and p.is_file(),'更新地址不存在，请填写HTTPS地址或绝对文件路径')
    return p.open('rb')

def read_manifest(channel,kind):
    with open_resource(channel) as response:raw=response.read(1024*1024+1)
    require(len(raw)<=1024*1024,'更新清单过大')
    value=json.loads(raw.decode('utf-8'))
    require(value.get('app_id')==APP_ID,'更新清单不属于本软件')
    version(value.get('version'))
    package=value.get('packages',{}).get(kind)
    require(isinstance(package,dict),'此版本没有适合当前程序类型的更新包')
    require(re.fullmatch('[a-fA-F0-9]{64}',str(package.get('sha256',''))),'更新包缺少SHA256校验值')
    require(type(package.get('size')) is int and 0<package['size']<=MAX_ZIP,'更新包大小无效或超过150MB')
    location=package.get('url');require(isinstance(location,str) and location,'更新包地址为空')
    if channel.startswith('https://'):
        location=urllib.parse.urljoin(channel,location)
        require(location.startswith('https://'),'在线更新包必须使用HTTPS')
    else:
        if not location.startswith('https://'):
            location=str((Path(channel).parent/location).resolve())
    return {'version':value['version'],'notes':str(value.get('notes',''))[:12000],'package':{**package,'url':location},'kind':kind}

def safe_extract(archive,destination,kind,expected_version):
    destination.mkdir(parents=True,exist_ok=False)
    names=set();total=0
    with zipfile.ZipFile(archive) as z:
        require(len(z.infolist())<=10000,'更新包文件数量过多')
        for member in z.infolist():
            raw=member.orig_filename
            require('\\' not in raw and ':' not in raw and '\x00' not in raw,'更新包含非法路径')
            p=PurePosixPath(raw)
            require(not p.is_absolute() and p.parts and all(x not in ('.','..') and x.rstrip(' .')==x for x in p.parts),'更新包含越界路径')
            require(not any(re.fullmatch(r'(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?',x,re.I) for x in p.parts),'更新包含保留文件名')
            require(not stat.S_ISLNK(member.external_attr>>16),'更新包不能包含符号链接')
            folded=str(p).casefold();require(folded not in names,'更新包包含重名文件');names.add(folded)
            require(p.parts[0].lower() not in ('data','updates') and not raw.lower().endswith('.log'),'更新包不能包含用户数据或日志')
            total+=member.file_size;require(total<=MAX_EXPANDED,'更新包解压体积过大')
            target=destination.joinpath(*p.parts)
            require(target.resolve().is_relative_to(destination.resolve()),'更新包路径越界')
            if member.is_dir():target.mkdir(parents=True,exist_ok=True);continue
            target.parent.mkdir(parents=True,exist_ok=True)
            with z.open(member) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst)
    metadata=json.loads((destination/'release.json').read_text('utf-8'))
    require(metadata=={'app_id':APP_ID,'version':expected_version,'kind':kind},'包内版本与清单不匹配')
    required=['热血短剧工作台.exe','_internal/index.html','update-helper.exe'] if kind=='windows-x64' else ['app.py','launch.py','updater.py','index.html','templates/reference.docx']
    for name in required:require((destination/name).is_file(),'更新包缺少 '+name)

def prepare(root,release):
    global STATE
    try:
        staging=root.parent/('.ReXueUpdate-'+secrets.token_hex(8));staging.mkdir()
        archive=staging/'update.zip';package=release['package'];h=hashlib.sha256();size=0
        require(shutil.disk_usage(root.parent).free>MAX_EXPANDED*2,'磁盘空间不足，至少需要约1.2GB空闲空间')
        with open_resource(package['url']) as src,archive.open('wb') as dst:
            while True:
                chunk=src.read(256*1024)
                if not chunk:break
                size+=len(chunk);require(size<=package['size'],'下载大小超过更新清单声明')
                dst.write(chunk);h.update(chunk)
                with GUARD:STATE.update(progress=round(size/package['size']*100))
        require(size==package['size'] and h.hexdigest().lower()==package['sha256'].lower(),'更新包大小或SHA256校验失败，未安装')
        payload=staging/'payload';safe_extract(archive,payload,release['kind'],release['version'])
        with GUARD:STATE.update(status='ready',message='更新已下载并校验。保存当前作品后可重启升级。',stage=str(staging),release=release,progress=100)
    except Exception as e:
        with GUARD:STATE.update(status='error',message=str(e),progress=0)

def action(app,server,route,data):
    root=install_root(app)
    with GUARD:
        if route=='/api/update/status':
            last=state_dir(root)/'last-result.json'
            return {'current':VERSION,'kind':mode(),'channel':settings(root)['channel'],**{k:v for k,v in STATE.items() if k!='stage'},'last_result':json.loads(last.read_text('utf-8')) if last.exists() else None}
        require(STATE['status'] not in ('checking','downloading','installing'),'更新任务正在进行，请稍候')
        if route=='/api/update/config':
            channel=str(data.get('channel','')).strip()
            require(not channel or channel.startswith('https://') or Path(channel).is_absolute(),'请填写HTTPS地址或本机绝对路径')
            save_json(state_dir(root)/'config.json',{'channel':channel});STATE.clear();STATE.update(status='idle',message='更新来源已保存。');return {'ok':True}
        if route=='/api/update/check':
            channel=settings(root)['channel'];require(channel,'尚未配置发布地址。请由软件提供者设置一次更新来源。')
            STATE.update(status='checking',message='正在检查更新……')
            def check():
                try:
                    release=read_manifest(channel,mode())
                    newer=version(release['version'])>version(VERSION)
                    with GUARD:STATE.update(status='available' if newer else 'current',message='发现新版本，可下载更新。' if newer else '当前已是最新版本。',release=release)
                except Exception as e:
                    with GUARD:STATE.update(status='error',message='检查失败：'+str(e))
            threading.Thread(target=check,daemon=True).start();return {'ok':True}
        if route=='/api/update/download':
            require(STATE['status']=='available','请先检查并找到新版本')
            release=copy.deepcopy(STATE['release']);STATE.update(status='downloading',message='正在下载并校验更新……',progress=0)
            threading.Thread(target=prepare,args=(root,release),daemon=True).start();return {'ok':True}
        if route=='/api/update/install':
            require(STATE['status']=='ready','请先下载并校验更新')
            require(data.get('saved') is True,'请先保存当前编辑再升级')
            require(not any(j['status']=='running' for j in app.JOBS.values()),'仍有AI任务在运行，请完成后再更新')
            stage=Path(STATE['stage']);kind=mode();token=secrets.token_hex(24)
            job={'root':str(root),'stage':str(stage),'parent_pid':os.getpid(),'kind':kind,'version':STATE['release']['version'],'token':token,'state_dir':str(state_dir(root)),'python':sys.executable if kind=='source' else None}
            save_json(stage/'job.json',job)
            if kind=='windows-x64':
                shutil.copy2(root/'update-helper.exe',stage/'update-helper.exe');cmd=[str(stage/'update-helper.exe'),'--install',str(stage/'job.json')]
            else:
                shutil.copy2(Path(__file__),stage/'updater.py');cmd=[sys.executable,str(stage/'updater.py'),'--install',str(stage/'job.json')]
            subprocess.Popen(cmd,cwd=stage,creationflags=subprocess.CREATE_NO_WINDOW)
            STATE.update(status='installing',message='正在退出旧版本并升级。新版本会自动打开。')
            threading.Timer(1,server.shutdown).start()
            return {'ok':True,'message':STATE['message']}
    raise ValueError('未知更新操作')

def wait_parent(pid):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong];kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    handle=kernel.OpenProcess(0x00100000,False,pid)
    if not handle:return
    try:require(kernel.WaitForSingleObject(handle,60000)==0,'旧程序未退出，取消更新')
    finally:kernel.CloseHandle(handle)

def transaction(job, launch_check):
    root=Path(job['root']).resolve();stage=Path(job['stage']).resolve();payload=stage/'payload'
    require(root.parent==stage.parent and stage.name.startswith('.ReXueUpdate-'),'升级临时目录无效')
    require(root!=root.parent and payload.is_dir() and root.is_dir(),'安装目录无效')
    require((root/('热血短剧工作台.exe' if job['kind']=='windows-x64' else 'launch.py')).is_file(),'不是有效的软件目录')
    backup=root.with_name(root.name+'.rollback-'+stage.name.split('-')[-1])
    require(not backup.exists(),'回滚目录已存在')
    if job['kind']=='source':
        for name in ['data','startup.log','运行输出.log','运行错误.log']:
            source=root/name
            require(not (payload/name).exists(),'更新包尝试覆盖用户数据')
            if source.is_dir():shutil.copytree(source,payload/name)
            elif source.is_file():shutil.copy2(source,payload/name)
    root.rename(backup)
    try:
        payload.rename(root)
        launch_check(root,job)
        return backup
    except Exception:
        if root.exists():root.rename(stage/'failed-version')
        backup.rename(root)
        raise

def command(root,job,health=False):
    cmd=[str(root/'热血短剧工作台.exe')] if job['kind']=='windows-x64' else [job['python'],str(root/'launch.py')]
    if health:cmd+=['--update-health',str(Path(job['stage'])/'health.json'),'--update-token',job['token']]
    return cmd

def launch_checked(root,job):
    p=subprocess.Popen(command(root,job,True),cwd=root,creationflags=subprocess.CREATE_NO_WINDOW)
    health=Path(job['stage'])/'health.json'
    try:
        for _ in range(200):
            if p.poll() is not None:raise ValueError('新程序提前退出')
            if health.exists():
                value=json.loads(health.read_text('utf-8'))
                require(value['token']==job['token'] and value['version']==job['version'],'新版本启动验证不匹配')
                require(re.fullmatch(r'http://127\.0\.0\.1:\d+',value['url']),'启动地址无效')
                try:
                    with urllib.request.urlopen(value['url'],timeout=2) as response:require(response.status==200,'界面未启动')
                    return
                except (OSError,ValueError):pass
            time.sleep(.1)
        raise ValueError('新版本启动超时')
    except Exception:
        p.terminate();p.wait(timeout=10);raise

def worker(job_path):
    job=json.loads(Path(job_path).read_text('utf-8'));result=Path(job['state_dir'])/'last-result.json'
    try:
        wait_parent(int(job['parent_pid']))
        backup=transaction(job,launch_checked)
        save_json(result,{'ok':True,'version':job['version'],'message':'升级成功，旧版本已保留在回滚目录。','backup':str(backup)})
    except Exception as e:
        save_json(result,{'ok':False,'message':'升级未完成：'+str(e)+'。原版本已保留或恢复。'})
        # Never start a second old instance when the parent has not exited.
        if '旧程序未退出' not in str(e):
            try:subprocess.Popen(command(Path(job['root']),job),cwd=job['root'],creationflags=subprocess.CREATE_NO_WINDOW)
            except Exception:pass

if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='--install':worker(sys.argv[2])
